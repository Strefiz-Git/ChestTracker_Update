package red.jackf.chesttracker.impl.gui.widget;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.world.item.ItemStack;

public record SimpleItemWidget(ItemStack stack, int x, int y, int size) implements Renderable {
    private static final int DEFAULT_ITEM_SIZE = 18;

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        final float factor = (float) this.size / DEFAULT_ITEM_SIZE;

        graphics.pose().pushMatrix();
        graphics.pose().translate(x, y);
        graphics.pose().scale(factor, factor);
        graphics.fakeItem(stack, 0, 0);
        graphics.pose().popMatrix();
    }
}
