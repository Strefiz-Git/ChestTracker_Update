package red.jackf.chesttracker.impl.compat.mods.jade;

import net.minecraft.client.gui.layouts.LayoutElement;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import red.jackf.chesttracker.api.memory.Memory;
import red.jackf.chesttracker.api.memory.MemoryBankAccess;
import red.jackf.chesttracker.impl.ChestTracker;
import red.jackf.chesttracker.impl.util.ItemStacks;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.JadeIds;
import snownee.jade.api.config.IPluginConfig;
import snownee.jade.api.theme.IThemeHelper;
import snownee.jade.api.ui.JadeUI;
import snownee.jade.api.ui.ScreenDirection;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class JadeClientContentsPreview implements IBlockComponentProvider {
    public static final JadeClientContentsPreview INSTANCE = new JadeClientContentsPreview();
    private JadeClientContentsPreview() {}

    public static final Identifier ID = ChestTracker.id("memory_preview");

    private static void possiblyAddItems(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config, Memory memory) {
        if (config.get(JadeIds.UNIVERSAL_ITEM_STORAGE) &&
                (accessor.getServerData().contains("JadeItemStorage") // < 15.8.0
                        || accessor.getServerData().contains(JadeIds.UNIVERSAL_ITEM_STORAGE.toString()))) // >= 15.8.0
            return;

        if (config.get(JadeIds.MC_FURNACE)
                && accessor.getBlock() instanceof AbstractFurnaceBlock &&
                (accessor.getServerData().contains("furnace") // < 15.7.0
                        || accessor.getServerData().contains(JadeIds.MC_FURNACE.toString()))) // >=15.7.0
            return;

        var stacks = ItemStacks.flattenStacks(memory.items(), true);

        int max = config.getInt(accessor.showDetails() ? JadeIds.UNIVERSAL_ITEM_STORAGE_DETAILED_AMOUNT : JadeIds.UNIVERSAL_ITEM_STORAGE_NORMAL_AMOUNT);
        int perLine = config.getInt(JadeIds.UNIVERSAL_ITEM_STORAGE_ITEMS_PER_LINE);

        List<List<LayoutElement>> lines = new ArrayList<>();
        List<LayoutElement> currentLine = new ArrayList<>(perLine);

        for (int i = 0; i < max && i < stacks.size(); i++) {
            ItemStack item = stacks.get(i);
            currentLine.add(JadeUI.item(item));
            if (currentLine.size() == perLine) {
                lines.add(currentLine);
                currentLine = new ArrayList<>(perLine);
            }
        }

        if (!currentLine.isEmpty()) lines.add(currentLine);

        for (List<LayoutElement> line : lines) {
            tooltip.add(line);
            tooltip.setLineMargin(-1, ScreenDirection.DOWN, -1);
        }
    }

    @Override
    public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) {
        MemoryBankAccess.INSTANCE.getLoaded().ifPresent(bank -> {
            Optional<Memory> memory = bank.getMemory(accessor.getLevel(), accessor.getPosition());
            if (memory.isEmpty()) return;
            possiblyAddItems(tooltip, accessor, config, memory.get());

            Component name = memory.get().renderName();
            if (name != null) {
                tooltip.replace(JadeIds.CORE_OBJECT_NAME, IThemeHelper.get().title(name));
            }
        });
    }

    @Override
    public Identifier getUid() {
        return ID;
    }
}
