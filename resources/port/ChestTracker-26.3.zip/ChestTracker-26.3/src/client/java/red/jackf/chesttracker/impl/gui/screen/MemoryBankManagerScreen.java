package red.jackf.chesttracker.impl.gui.screen;

import com.mojang.datafixers.util.Pair;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import red.jackf.chesttracker.impl.config.ChestTrackerConfig;
import red.jackf.chesttracker.impl.gui.GuiConstants;
import red.jackf.chesttracker.impl.gui.util.TextColours;
import red.jackf.chesttracker.impl.gui.widget.CustomEditBox;
import red.jackf.chesttracker.impl.gui.widget.StringSelectorWidget;
import red.jackf.chesttracker.impl.gui.widget.TextWidget;
import red.jackf.chesttracker.impl.memory.MemoryBankAccessImpl;
import red.jackf.chesttracker.impl.memory.MemoryBankImpl;
import red.jackf.chesttracker.impl.memory.metadata.Metadata;
import red.jackf.chesttracker.impl.storage.Storage;
import red.jackf.chesttracker.impl.util.GuiUtil;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * Allows a user to select (if in game) and manage memory banks.
 */
public class MemoryBankManagerScreen extends BaseUtilScreen {
    private static final int BUTTON_SIZE = 12;
    private static final int SEARCH_TOP = 19;
    private static final int SEARCH_HEIGHT = 12;
    private static final int LIST_TOP = 36;


    private final Runnable onRemoveScreen;
    private final Runnable afterBankLoaded;

    private EditBox search = null;
    private StringSelectorWidget<String> memoryBankList;
    private Map<String, Metadata> memoryBanks;

    /**
     * @param onRemoveScreen  - Runnable to run on cancel, usually when pressing escape or a back button
     * @param afterBankLoaded - Runnable to run after selection of a new memory bank
     */
    public MemoryBankManagerScreen(Runnable onRemoveScreen, Runnable afterBankLoaded) {
        super(Component.translatable("chesttracker.gui.memoryManager"));
        this.onRemoveScreen = onRemoveScreen;
        this.afterBankLoaded = afterBankLoaded;
    }

    /**
     * @param onRemoveScreen  - Screen to open on cancel, usually when pressing escape or a back button
     * @param afterBankLoaded - Runnable to run after selection of a new memory bank
     */
    public MemoryBankManagerScreen(Supplier<@Nullable Screen> onRemoveScreen, Runnable afterBankLoaded) {
        this(() -> Minecraft.getInstance().gui.setScreen(onRemoveScreen.get()), afterBankLoaded);
    }

    public MemoryBankManagerScreen(@Nullable Screen parent, Runnable afterBankLoaded) {
        this(() -> parent, afterBankLoaded);
    }

    @Override
    protected void init() {
        super.init();

        this.memoryBanks = Storage.getAllIds().stream()
                .sorted()
                .map(id -> Pair.of(id, Storage.loadMetadata(id)))
                .filter(pair -> pair.getSecond().isPresent())
                .collect(Collectors.toMap(Pair::getFirst, p -> p.getSecond().get(), (a, b) -> a, LinkedHashMap::new));

        // backend label
        this.addRenderableOnly(new TextWidget(this.left + GuiConstants.MARGIN,
                top + GuiConstants.MARGIN,
                this.menuWidth - GuiConstants.MARGIN - 2 * GuiConstants.SMALL_MARGIN - BUTTON_SIZE,
                Component.translatable("chesttracker.gui.memoryManager.selectedBackend", ChestTrackerConfig.INSTANCE.instance().storage.storageBackend.name()),
                TextColours.getLabelColour(),
                TextWidget.Alignment.RIGHT));

        // close button
        this.addRenderableWidget(GuiUtil.close(
                this.left + this.menuWidth - BUTTON_SIZE - GuiConstants.SMALL_MARGIN,
                this.top + GuiConstants.SMALL_MARGIN,
                b -> this.onClose()));

        var inGame = Minecraft.getInstance().level != null;

        if (inGame) {
            // button to create a new memory; not shown if not ingame
            this.addRenderableWidget(new ImageButton(
                            this.left + menuWidth - BUTTON_SIZE - GuiConstants.SMALL_MARGIN,
                            this.top + SEARCH_TOP,
                            BUTTON_SIZE,
                            BUTTON_SIZE,
                            GuiUtil.twoSprite("new_memory_bank/button"),
                            b -> openCreateScreen(afterBankLoaded)))
                    .setTooltip(Tooltip.create(Component.translatable("chesttracker.gui.memoryManager.newMemoryBank")));
        }

        // search bar
        this.search = this.addRenderableWidget(new CustomEditBox(
                Minecraft.getInstance().font,
                this.left + GuiConstants.MARGIN,
                this.top + SEARCH_TOP,
                this.menuWidth - 2 * GuiConstants.MARGIN - (inGame ? BUTTON_SIZE : 0),
                SEARCH_HEIGHT,
                this.search,
                Component.translatable("chesttracker.gui.memoryManager.search")
        ));
        this.search.setTextColor(TextColours.getTextColour());
        this.search.setHint(Component.translatable("chesttracker.gui.memoryManager.search"));
        this.search.setResponder(term -> {
            // update string list options
            this.memoryBankList.setOptions(this.memoryBanks.entrySet().stream()
                    .filter(entry -> {
                        var name = entry.getValue().getName();
                        if (name == null) name = entry.getKey();
                        return name.toLowerCase().contains(term.toLowerCase());
                    }).collect(Collectors.toMap(
                            Map.Entry::getKey,
                            e -> {
                                if (e.getValue().getName() != null) {
                                    return Component.literal(e.getValue().getName()); // custom user-defined name
                                } else {
                                    var id = Component.literal(e.getKey());
                                    if (ChestTrackerConfig.INSTANCE.instance().gui.hideMemoryIds)
                                        id.setStyle(Style.EMPTY.withObfuscated(true));
                                    return id;
                                }
                            },
                            (a, b) -> a,
                            LinkedHashMap::new
                    )));
        });

        // String list
        this.memoryBankList = this.addRenderableWidget(new StringSelectorWidget<>(
                this.left + GuiConstants.MARGIN,
                this.top + LIST_TOP,
                this.menuWidth - 2 * GuiConstants.MARGIN,
                this.menuHeight - LIST_TOP - GuiConstants.MARGIN,
                CommonComponents.EMPTY,
                id -> openEditScreen(afterBankLoaded, id)
        ));
        this.memoryBankList.setHighlight(MemoryBankAccessImpl.INSTANCE.getLoadedInternal().map(MemoryBankImpl::getId).orElse(null));

        this.search.setValue("");
    }

    private void openCreateScreen(Runnable afterBankLoaded) {
        Minecraft.getInstance().gui.setScreen(new CreateMemoryBankScreen(this, afterBankLoaded));
    }

    private void openEditScreen(Runnable afterBankLoaded, @NotNull String bankId) {
        Minecraft.getInstance().gui.setScreen(new EditMemoryBankScreen(this, afterBankLoaded, bankId));
    }

    @Override
    public void onClose() {
        onRemoveScreen.run();
    }
}
